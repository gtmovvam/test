#!/usr/bin/python
from __future__ import print_function

#default libs
import argparse
import os
import re
import sys

#3rd party libs
import boto3
import jinja2
import seco.range

regions = [
    'us-east-1',
    'us-west-2',
    'eu-west-1',
    'ap-northeast-1']

CACHE_KEYS = [
    'NAGIOS_HOST',
    'ELB',
    'TARGET_GROUPS',
    'ALERT_CONTACT',
    'SECURITY_GROUPS',
    'ALERT_CHECK',
    'ALERT_CLUSTER_THRESHOLD']


#def eprint(*args, **kwargs):
#    print(*args, file=sys.stderr, **kwargs)


def cache_elbs():
    return(True)


def range_query(range_session, query):
    result = range_session.expand(query)
    result = map(lambda s: s.strip('\'"'), result)
    while '' in result:
        result.pop(result.index(''))
    return(result)


def build_cache(range_session, cache, regions, clusters=[]):
    if clusters is []:
        clusters = range_query(range_session, 'allclusters()')
  
    for cluster in clusters:
        if cluster == 'all':
            continue
        if not re.match(r'^[a-z-_]+[0-9]{0,3}', cluster):
            print("Skipping cluster, bad RE. {}".format(cluster),
                  file=sys.stderr)
            continue
  
        try:
            region = range_query(range_session, '%{'+cluster+'}:REGION')[0]
        except seco.range.RangeException:
            region = 'us-east-1'

        if not region:
            region = 'us-east-1' # Default to this for old clusters.

        region = re.sub(r'[^a-z0-9-]', '', region)

        cache.setdefault('region', {})
        cache[region].setdefault('h2c', {})

        try:
            hosts = range_query(range_session, '%{'+cluster+'}:ALL')
        except seco.range.RangeException:
            print("Didn't get hosts from :ALL", file=sys.stderr)
            continue

        cache['cluster'].setdefault(cluster, {})
        for key in CACHE_KEYS:
            try:
                val = range_query(range_session, '%{'+cluster+'}:'+key)
            except seco.range.RangeException:
                continue
            cache['cluster'][cluster][key] = val

        for host in hosts:
            if not re.match(r'^ec2-', host):
                continue # If not an ec2 host, probably not real?
            if cache[region]['h2c'].get(host):
                continue # Host already cached?
            cache[region]['h2c'][host] = cluster
    return cache


def host_cache(range_session, cache, region, hostname):
    if cache[region]['h2c'].get(hostname):
        return(cache) # Host is already cached.
    else:
        cache[region]['h2c'][hostname] = None
        try:
            cache = build_cache(range_session, cache, [ region ],
                range_query(range_session, "clusters({})".format(hostname)))
        except seco.range.RangeException as e:
            print("Range query failure for {}: {}".format(hostname, e),
                  file=sys.stderr)
            cache[region]['h2c'][hostname] = "unknown"
    return cache


# Custom filter method
def regex_replace(s, find, replace):
    """A non-optimal implementation of a regex filter"""
    return re.sub(find, replace, s)


def print_templates(regions, templates, lates):
    range_session = seco.range.Range(host='range.mgmt.xad.com')
    jinja_env = jinja2.Environment(
        loader=jinja2.FileSystemLoader(os.path.dirname(os.path.abspath(__file__))),
        trim_blocks = True)
    jinja_env.filters['regex_replace'] = regex_replace
    cache = {} 
    cache.setdefault('cluster', {})
    cache.setdefault('backwards', {})
    cache.setdefault('count', {})
    outfiles = {}
    jtemplates = {}
  
    for region in regions:
        print("Connecting to {}".format(region), file=sys.stderr)
        boto3_session = boto3.Session(region_name = region)
        ec2 = boto3_session.resource('ec2')
        elb = boto3_session.client('elb')
        elbv2 = boto3_session.client('elbv2')
        cache.setdefault('elb', {})
        cache.setdefault('elbv2', {})
        cache['elb'].setdefault('LoadBalancerDescriptions', [])
        cache['elbv2'].setdefault('LoadBalancers', [])
        cache['elbv2'].setdefault('TargetGroups', [])
        tmp = elb.describe_load_balancers(PageSize=400)
        tmp2 = elbv2.describe_load_balancers(PageSize=400)
        tmp3 = elbv2.describe_target_groups(PageSize=400)
        for item in tmp['LoadBalancerDescriptions']:
            cache['elb']['LoadBalancerDescriptions'].append(item)
        for item in tmp2['LoadBalancers']:
            cache['elbv2']['LoadBalancers'].append(item)
        for item in tmp3['TargetGroups']:
            cache['elbv2']['TargetGroups'].append(item)
        cache.setdefault(region, {})
        cache[region].setdefault('h2c', {})
        cache.setdefault('cluster', {})
  
        for instance in ec2.instances.all():
            hostname = instance.public_dns_name
            if not hostname:
                print("Got bad hostname for {}".format(instance.instance_id),
                      file=sys.stderr)
                continue

            if cache[region]['h2c'].get(hostname):
                cluster = cache[region]['h2c'].get(hostname)
            else:
                cache = host_cache(range_session, cache, region, hostname)
                cluster = cache[region]['h2c'].get(hostname)

            if cluster is None:
                print("Didn't get a cluster for {}".format(hostname),
                      file=sys.stderr)
                continue
  
            if not re.match(r'^ec2-', hostname):
                continue # Hostname wasn't defined?
          
            c = {} 
            if cache['cluster'].get(cluster):
                c = cache['cluster'][cluster]

            for template in templates:
                files = template.split(":", 2)
                infile = files[0]
                if not outfiles.get(files[1]):
                    outfiles[files[1]] = open(files[1], 'w')
                if not jtemplates.get(infile):
                    jtemplates[infile] = jinja_env.get_template(infile) 
                outfile = outfiles[files[1]]

                try:
                    outfile.write(jtemplates[infile].render(
                        range = range_session,
                        cache = c,
                        i = instance,
                        cluster = cluster,
                        count = cache['count'].get(template, 0),
                        allcache = cache))
                except Exception as e:
                    print("Debug info (instance): ", file=sys.stderr)
                    print(str(e), file=sys.stderr)
                    print("For host: {}, region: {}, cluster: {}".format(
                        hostname,
                        region,
                        cluster), file=sys.stderr)
                    continue
                cache['count'][template] = cache['count'].get(template, 0) + 1
    for cluster in cache['cluster'].keys():
        for key in cache['cluster'][cluster].keys():
            for val in cache['cluster'][cluster][key]:
                cache.setdefault('backwards', {})
                cache['backwards'].setdefault(key, {})
                cache['backwards'][key][val] = 1

    for template in lates:
        files = template.split(":", 2)
        infile = files[0]
        if not outfiles.get(files[1]):
            outfiles[files[1]] = open(files[1], 'w')
        if not jtemplates.get(infile):
            jtemplates[infile] = jinja_env.get_template(infile)
        outfile = outfiles[files[1]]
        try:
            outfile.write(jtemplates[infile].render(
                range = range_session,
                allcache = cache,
                elb = cache['elb'],
                elbv2 = cache['elbv2']))
        except Exception as e:
            print("Debug info (late): ", file=sys.stderr)
            print(str(e), file=sys.stderr)
            continue


if __name__ == '__main__':
    parser = argparse.ArgumentParser(
        formatter_class = argparse.RawDescriptionHelpFormatter,
        description=("Iterate through aws nodes, add range data, and then "
                     "parse jinja templates per node."))
    parser.add_argument("-r", "--region", default=regions, nargs="*",
        help="Specify a region to override the default of all.")
    parser.add_argument("-t", "--template", nargs="*", default=[],
        help=("Specify a jinja template and output file. Format: "
              "`/path/to/template.templ:/path/to/output.conf`. May specify "
              "more than one template:output pair."))
    parser.add_argument("-l", "--late", default=[], nargs="*",
        help=("Specify a jinja template to run at the very end, after all "
              "caches are created. This might be used to generate data about "
              "the data cached."))
    args = parser.parse_args()
    if args.template is None and args.late is None:
        parser.error("At least one of --template or --late is required.")
  
    print_templates(args.region, args.template, args.late)
